<div class="customer-title mx-3 mb-0 container-fluid">
<h6>Our software proficiency</h6>
</div>
<section class="company-icons">
    
            <div class="row">
       <div class="col"></div>
            
            <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/a2x-01.png" alt="image01" ></li>
                <li><img src="img/icon2/adp-01.png" alt="image02" ></li>
                <li><img src="img/icon2/amazon-01.png" alt="image03" ></li>
                <li><img src="img/icon2/assetguru-01.png" alt="image04" ></li>
                <li><img src="img/icon2/autoentry-01.png" alt="image05" ></li>
                <li><img src="img/icon2/bigcommerce-01.png" alt="image06" ></li>
                <li><img src="img/icon2/capsule-01.png" alt="image07" ></li>
                <li><img src="img/icon2/cin7-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/clickup-01.png" alt="image01" ></li>
                <li><img src="img/icon2/Crm-01.png" alt="image02" ></li>
                <li><img src="img/icon2/datadear.png" alt="image03" ></li>
                <li><img src="img/icon2/dear%20system-01.png" alt="image04" ></li>
                <li><img src="img/icon2/deputy-01.png" alt="image05" ></li>
                <li><img src="img/icon2/dropbox.png" alt="image06" ></li>
                <li><img src="img/icon2/dryrun-01.png" alt="image07" ></li>
                <li><img src="img/icon2/dyanmics-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/expensify-01.png" alt="image01" ></li>
                <li><img src="img/icon2/facebook-01.png" alt="image02" ></li>
                <li><img src="img/icon2/fathom.png" alt="image03" ></li>
                <li><img src="img/icon2/float.png" alt="image04" ></li>
                <li><img src="img/icon2/freshbooks-01.png" alt="image05" ></li>
                <li><img src="img/icon2/futrli.png" ></li>
                <li><img src="img/icon2/gmail-01.png" alt="image07" ></li>
                <li><img src="img/icon2/googledrive-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/freshdesk-01.png" alt="image01" ></li>
                <li><img src="img/icon2/gSuite-01.png" alt="image02" ></li>
                <li><img src="img/icon2/handshake-01.png" alt="image03" ></li>
                <li><img src="img/icon2/harvest-01.png" alt="image04" ></li>
                <li><img src="img/icon2/hibstaff-01.png" alt="image05" ></li>
                <li><img src="img/icon2/hubdoc.png" alt="image06" ></li>
                <li><img src="img/icon2/hubspot-logo-01-01.png" alt="image07" ></li>
                <li><img src="img/icon2/insightly-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/jira-01.png" alt="image01" ></li>
                <li><img src="img/icon2/klipfolio-01.png" alt="image02" ></li>
                <li><img src="img/icon2/linkedin-01.png" alt="image03" ></li>
                <li><img src="img/icon2/microsoft.png" alt="image04" ></li>
                <li><img src="img/icon2/netsuite.png" alt="image05" ></li>
                <li><img src="img/icon2/onedrive-01.png" alt="image06" ></li>
                <li><img src="img/icon2/paypal-01.png" alt="image07" ></li>
                    <li><img src="img/icon2/onedrive-01.png" alt="image06" ></li>
               
                </ul>
                </div>
            </div>

            <div class="col"></div>
        </div>
    <div class="row">
       <div class="col"></div>
  
            <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/PowerBI-01.png" alt="image01" ></li>
                <li><img src="img/icon2/quickbook.png" alt="image02" ></li>
                <li><img src="img/icon2/receiptbank-01.png" alt="image03" ></li>
                <li><img src="img/icon2/sega.png" alt="image04" ></li>
                <li><img src="img/icon2/sheets-01.png" alt="image05" ></li>
                <li><img src="img/icon2/shopify-01.png" alt="image06" ></li>
                <li><img src="img/icon2/simplepay-01.png" alt="image07" ></li>
                <li><img src="img/icon2/smartsheet.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/spotlight.png" alt="image01" ></li>
                <li><img src="img/icon2/stripe-01.png" alt="image02" ></li>
                <li><img src="img/icon2/sumhr-01.png" alt="image03" ></li>
                <li><img src="img/icon2/tally-01.png" alt="image04" ></li>
                <li><img src="img/icon2/tradegecko-01.png" alt="image05" ></li>
                <li><img src="img/icon2/tradify-01.png" alt="image06" ></li>
                <li><img src="img/icon2/twitter-01.png" alt="image07" ></li>
                <li><img src="img/icon2/unleashed-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/vend-01.png" alt="image01" ></li>
                <li><img src="img/icon2/woocommerce-01.png" alt="image02" ></li>
                <li><img src="img/icon2/workflow-01.png" alt="image03" ></li>
                <li><img src="img/icon2/xero-01.png" alt="image04" ></li>
                <li><img src="img/icon2/youtube-01.png" alt="image05" ></li>
                <li><img src="img/icon2/zapier-01.png" ></li>
                <li><img src="img/icon2/zendesk-01.png" alt="image07" ></li>
                <li><img src="img/icon2/zoho%20analytics-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                 <li><img src="img/icon2/zoho-01.png" alt="image05" ></li>
                <li><img src="img/icon2/shopify-01.png" alt="image06" ></li>
                <li><img src="img/icon2/simplepay-01.png" alt="image07" ></li>
                <li><img src="img/icon2/smartsheet.png" alt="image08" ></li>
                <li><img src="img/icon2/stripe-01.png" alt="image02" ></li>
                <li><img src="img/icon2/sumhr-01.png" alt="image03" ></li>
                <li><img src="img/icon2/tally-01.png" alt="image04" ></li>
                <li><img src="img/icon2/tradegecko-01.png" alt="image05" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
               <li><img src="img/icon2/sheets-01.png" alt="image05" ></li>
                <li><img src="img/icon2/shopify-01.png" alt="image06" ></li>
                <li><img src="img/icon2/simplepay-01.png" alt="image07" ></li>
                <li><img src="img/icon2/smartsheet.png" alt="image08" ></li>
               <li><img src="img/icon2/autoentry-01.png" alt="image05" ></li>
                <li><img src="img/icon2/bigcommerce-01.png" alt="image06" ></li>
                <li><img src="img/icon2/capsule-01.png" alt="image07" ></li>
                <li><img src="img/icon2/cin7-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>

          <div class="col"></div>  
        </div>
         <div class="row">
       <div class="col"></div>
  
            <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                  <li><img src="img/icon2/sheets-01.png" alt="image05" ></li>
                <li><img src="img/icon2/shopify-01.png" alt="image06" ></li>
                <li><img src="img/icon2/simplepay-01.png" alt="image07" ></li>
                <li><img src="img/icon2/smartsheet.png" alt="image08" ></li>
                <li><img src="img/icon2/stripe-01.png" alt="image02" ></li>
                <li><img src="img/icon2/sumhr-01.png" alt="image03" ></li>
                <li><img src="img/icon2/tally-01.png" alt="image04" ></li>
                <li><img src="img/icon2/tradegecko-01.png" alt="image05" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/clickup-01.png" alt="image01" ></li>
                <li><img src="img/icon2/Crm-01.png" alt="image02" ></li>
                <li><img src="img/icon2/datadear.png" alt="image03" ></li>
                <li><img src="img/icon2/dear%20system-01.png" alt="image04" ></li>
                <li><img src="img/icon2/deputy-01.png" alt="image05" ></li>
                <li><img src="img/icon2/dropbox.png" alt="image06" ></li>
                <li><img src="img/icon2/dryrun-01.png" alt="image07" ></li>
                <li><img src="img/icon2/dyanmics-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
                <li><img src="img/icon2/vend-01.png" alt="image01" ></li>
                <li><img src="img/icon2/woocommerce-01.png" alt="image02" ></li>
                <li><img src="img/icon2/workflow-01.png" alt="image03" ></li>
                <li><img src="img/icon2/xero-01.png" alt="image04" ></li>
                <li><img src="img/icon2/youtube-01.png" alt="image05" ></li>
                <li><img src="img/icon2/zapier-01.png" ></li>
                <li><img src="img/icon2/zendesk-01.png" alt="image07" ></li>
                <li><img src="img/icon2/zoho%20analytics-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
             <li><img src="img/icon2/spotlight.png" alt="image01" ></li>
                <li><img src="img/icon2/stripe-01.png" alt="image02" ></li>
                <li><img src="img/icon2/sumhr-01.png" alt="image03" ></li>
                <li><img src="img/icon2/tally-01.png" alt="image04" ></li>
                <li><img src="img/icon2/tradegecko-01.png" alt="image05" ></li>
                <li><img src="img/icon2/tradify-01.png" alt="image06" ></li>
                <li><img src="img/icon2/twitter-01.png" alt="image07" ></li>
                <li><img src="img/icon2/unleashed-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>
             <div class="col-lg-2 col-sm-2 col-2 col-md-2">
            <div class="slides">
                <ul>
             <li><img src="img/icon2/jira-01.png" alt="image01" ></li>
                <li><img src="img/icon2/klipfolio-01.png" alt="image02" ></li>
                <li><img src="img/icon2/linkedin-01.png" alt="image03" ></li>
                <li><img src="img/icon2/microsoft.png" alt="image04" ></li>
                <li><img src="img/icon2/netsuite.png" alt="image05" ></li>
                <li><img src="img/icon2/onedrive-01.png" alt="image06" ></li>
                <li><img src="img/icon2/paypal-01.png" alt="image07" ></li>
                <li><img src="img/icon2/amazon-01.png" alt="image08" ></li>
                </ul>
                </div>
            </div>

          <div class="col"></div>  
        </div>
</section>